package demo;

public class MainApplication {
    public static void main(String[] args) {
        UserService userService = new UserService();
        OrderManagementService orderManagementService = new OrderManagementService();
        PaymentGateway paymentGateway = new PaymentGateway();
        InvoiceGenerator invoiceGenerator = new InvoiceGenerator();

        userService.login("demo.user", "Pass12345", "10.0.0.8", true);
        orderManagementService.setOrderId("ORD-1001");
        orderManagementService.setCustomerId("CUST-801");
        orderManagementService.setTotalAmount(1850.00);
        orderManagementService.setExpedited(true);
        orderManagementService.finalizeOrder();

        boolean status = paymentGateway.processCharge("4111111111111111", 600, "USD", true);
        String invoiceId = invoiceGenerator.createInvoice("CUST-801", 1250.50, true, true);

        System.out.println("Charge status: " + status);
        System.out.println("Invoice created: " + invoiceId);
    }
}
