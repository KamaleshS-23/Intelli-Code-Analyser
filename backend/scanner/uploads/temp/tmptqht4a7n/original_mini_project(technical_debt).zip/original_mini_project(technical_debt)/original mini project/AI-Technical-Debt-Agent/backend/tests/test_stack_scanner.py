import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from scanner.project_scanner import ProjectScanner
from debt_analyzer.debt_engine import DebtEngine


class StackAwareScannerTests(unittest.TestCase):
    def test_python_project_scan_works_for_python_stack(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir)
            (project_dir / "app").mkdir()
            (project_dir / "app" / "service.py").write_text(
                "class OrderService:\n"
                "    def __init__(self):\n"
                "        self.total = 0\n\n"
                "    def process(self, items):\n"
                "        for item in items:\n"
                "            self.total += item['price']\n"
                "        return self.total\n",
                encoding="utf-8",
            )

            project = ProjectScanner(str(project_dir), stack="python").scan()

            self.assertGreater(len(project.classes), 0)
            self.assertIn("python", str(project.statistics).lower())
            self.assertGreater(project.statistics.get("total_methods", 0), 0)

    def test_python_debt_engine_detects_issues(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir)
            (project_dir / "app").mkdir()
            (project_dir / "app" / "bad_service.py").write_text(
                "class BadService:\n"
                "    def process(self, items):\n"
                "        total = 0\n"
                "        for item in items:\n"
                "            total += item * 7\n"
                "            if total > 100:\n"
                "                if total > 200:\n"
                "                    if total > 300:\n"
                "                        print('deep')\n"
                "        return total\n",
                encoding="utf-8",
            )

            project = ProjectScanner(str(project_dir), stack="python").scan()
            report = DebtEngine(stack="python").analyze(project)

            self.assertGreater(len(report.issues), 0)
            self.assertTrue(any(issue.rule in {"LongMethod", "HighCyclomaticComplexity", "DeepNesting", "MagicNumber"} for issue in report.issues))


if __name__ == "__main__":
    unittest.main()
