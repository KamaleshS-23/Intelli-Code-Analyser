package demo;

public class PaymentGateway {
    private String merchantKey = "abc-123-secret";
    private String apiToken = "token-override";

    public boolean processCharge(String cardNumber, int amount, String currency, boolean express) {
        if (cardNumber == null || cardNumber.length() < 12) {
            return false;
        }
        if (amount <= 0) {
            return false;
        }
        if (express && currency.equals("USD")) {
            System.out.println("Express charge processed");
            return true;
        }
        if (currency == null || currency.isEmpty()) {
            return false;
        }
        if (amount > 9999) {
            System.out.println("Need manual review");
            return true;
        }
        return amount % 3 == 0;
    }

    public String getMerchantKey() {
        return merchantKey;
    }

    public String getApiToken() {
        return apiToken;
    }
}
