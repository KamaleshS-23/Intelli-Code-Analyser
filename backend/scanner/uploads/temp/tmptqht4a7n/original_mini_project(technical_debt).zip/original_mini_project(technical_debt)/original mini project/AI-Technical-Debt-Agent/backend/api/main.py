import os
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

# backend/ must be on sys.path so flat imports (scanner.*, debt_analyzer.*) resolve
_BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(_BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(_BACKEND_DIR))

from fastapi import Depends, FastAPI, Header, HTTPException, UploadFile, File, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

from auth.deps import extract_token, optional_user, require_user
from auth.service import (
    get_scan_history_item,
    list_login_history,
    list_scan_history,
    login_user,
    logout_user,
    register_user,
    save_scan_history,
)
from ai_assistant.config import get_ai_settings
from ai_assistant.context_builder import build_project_context
from ai_assistant.orchestrator import AIChatOrchestrator
from scanner.scanner_service import ScannerService


SUPPORTED_STACKS = ["java", "python"]
STACK_ALIASES = {"java": "java", "python": "python", "py": "python"}


def normalize_stack(stack_value):
    if not stack_value:
        return "java"
    normalized = str(stack_value).strip().lower()
    return STACK_ALIASES.get(normalized, "java")


class AuthRequest(BaseModel):
    email: str
    password: str


class AIChatRequest(BaseModel):
    project_id: str | None = None
    scan_id: str | None = None
    conversation_id: str | None = None
    message: str
    context: dict | None = None


app = FastAPI(
    title="AI Technical Debt Agent API",
    description="API for scanning Java projects and calculating technical debt metrics",
    version="1.0.0"
)

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Services
scanner_service = ScannerService()
ai_orchestrator = AIChatOrchestrator()

# Find the absolute path of backend directory
BACKEND_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BACKEND_DIR / "static"
UPLOAD_TEMP_DIR = BACKEND_DIR / "scanner" / "uploads" / "temp"

# Create directories if they do not exist
STATIC_DIR.mkdir(exist_ok=True)
UPLOAD_TEMP_DIR.mkdir(parents=True, exist_ok=True)


def _persist_scan(user, result, source: str):
    if not user:
        return
    try:
        save_scan_history(user, result, source)
    except Exception:
        pass


@app.get("/api/health")
def health():
    mongo_ok = True
    mongo_error = None
    try:
        from db.mongo import ping

        ping()
    except Exception as exc:
        mongo_ok = False
        mongo_error = str(exc)
    return {"ok": True, "mongodb": mongo_ok, "mongodb_error": mongo_error}


@app.post("/api/auth/register")
def api_register(payload: AuthRequest):
    try:
        return register_user(payload.email, payload.password)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/auth/login")
def api_login(payload: AuthRequest):
    try:
        return login_user(payload.email, payload.password)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/auth/logout")
def api_logout(authorization: Optional[str] = Header(default=None)):
    logout_user(extract_token(authorization))
    return {"ok": True}


@app.get("/api/auth/me")
def api_me(user=Depends(require_user)):
    return {
        "id": str(user["_id"]),
        "email": user["email"],
    }


@app.get("/api/history")
def api_history(user=Depends(require_user)):
    return {
        "logins": list_login_history(user),
        "scans": list_scan_history(user),
    }


@app.get("/api/history/scans/{item_id}")
def api_history_item(item_id: str, user=Depends(require_user)):
    item = get_scan_history_item(user, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="History item not found.")
    return item


@app.get("/api/stacks")
def api_stacks():
    return {"supported": SUPPORTED_STACKS, "default": "java"}


@app.get("/api/sample")
def scan_sample(
    stack: str = Query("java"),
    user=Depends(optional_user),
):
    """Scans a pre-packaged project for the chosen stack."""
    stack_name = normalize_stack(stack)
    sample_dir_name = "SamplePythonProject" if stack_name == "python" else "SampleProject"
    sample_path = BACKEND_DIR / "scanner" / "uploads" / sample_dir_name
    if not sample_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Sample project not found at {sample_path}"
        )

    try:
        result = scanner_service.scan(str(sample_path), save_output=True, stack=stack_name)
        ai_orchestrator.register_scan(result)
        _persist_scan(user, result, "sample")
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/scan-path")
def scan_path(
    path: str = Query(..., description="Absolute path to the project directory to scan"),
    stack: str = Query("java"),
    user=Depends(optional_user),
):
    """Scans a local directory on the server."""
    target_path = Path(path)
    if not target_path.exists():
        raise HTTPException(
            status_code=400,
            detail=f"The specified path does not exist on the server: {path}"
        )

    stack_name = normalize_stack(stack)

    try:
        result = scanner_service.scan(str(target_path), save_output=True, stack=stack_name)
        ai_orchestrator.register_scan(result)
        _persist_scan(user, result, "path")
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/scan-upload")
async def scan_upload(
    file: UploadFile = File(..., description="ZIP archive of the project"),
    stack: str = Form("java"),
    user=Depends(optional_user),
):
    """
    Upload a project ZIP file, extract it, scan it, and clean up.
    """
    if not file.filename.endswith(".zip"):
        raise HTTPException(
            status_code=400,
            detail="Only ZIP file uploads are supported."
        )

    temp_extract_dir = Path(tempfile.mkdtemp(dir=str(UPLOAD_TEMP_DIR)))
    temp_zip_path = temp_extract_dir / file.filename
    stack_name = normalize_stack(stack)

    try:
        with open(temp_zip_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
            zip_ref.extractall(temp_extract_dir)

        temp_zip_path.unlink()

        scan_target = temp_extract_dir
        subdirs = [d for d in temp_extract_dir.iterdir() if d.is_dir()]

        if len(subdirs) == 1 and not any(f.is_file() for f in temp_extract_dir.iterdir()):
            scan_target = subdirs[0]

        result = scanner_service.scan(str(scan_target), save_output=True, stack=stack_name)
        ai_orchestrator.register_scan(result)
        _persist_scan(user, result, "upload")
        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    finally:
        try:
            shutil.rmtree(temp_extract_dir)
        except Exception:
            pass


@app.get("/api/ai/config")
def ai_config():
    settings = get_ai_settings()
    return {
        "provider": settings.provider,
        "model": settings.model,
        "enabled": settings.is_enabled,
        "status": "configured" if settings.is_enabled else "missing-api-key",
    }


@app.get("/api/ai/context")
def ai_context():
    context = build_project_context(ai_orchestrator.latest_scan)
    return context


@app.post("/api/ai/chat")
def ai_chat(payload: AIChatRequest):
    if not payload.message or not payload.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty.")

    scan_result = ai_orchestrator._choose_scan(payload.project_id, payload.scan_id)
    if not scan_result:
        raise HTTPException(
            status_code=400,
            detail="No project scan is available yet. Run a scan before using the AI assistant.",
        )

    try:
        return ai_orchestrator.chat(scan_result, payload.message.strip(), payload.context or {})
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"AI provider request failed: {exc}",
        ) from exc


class AIValidationRequest(BaseModel):
    code: str
    class_name: Optional[str] = None


@app.post("/api/ai/validate")
def ai_validate(payload: AIValidationRequest):
    """
    Feature 5: Validate Java code syntax and AST integrity.
    """
    from ai_assistant.tools import validate_java_code
    result = validate_java_code(payload.code)
    return result


@app.get("/")
def read_root():
    """
    Serves the main application page.
    """
    index_file = STATIC_DIR / "index.html"
    if not index_file.exists():
        return {"message": "Welcome to AI Technical Debt Agent. Frontend not created yet."}
    return FileResponse(index_file)


# Mount static assets directory
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
