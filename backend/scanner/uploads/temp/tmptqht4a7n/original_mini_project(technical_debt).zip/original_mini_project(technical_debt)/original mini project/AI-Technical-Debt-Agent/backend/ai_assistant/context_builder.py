from __future__ import annotations


def _safe_list(items):
    return items if isinstance(items, list) else []


def _extract_root_issue(issue: dict, index: int = 0):
    rule = issue.get("rule") or issue.get("name") or f"Issue {index + 1}"
    severity = issue.get("severity") or "medium"
    class_name = issue.get("class_name") or issue.get("className") or "UnknownClass"
    return {
        "rule": rule,
        "severity": severity,
        "class_name": class_name,
        "file_path": issue.get("file_path") or "",
        "method_name": issue.get("method_name") or issue.get("methodName") or "",
        "message": issue.get("message") or "",
        "suggestion": issue.get("suggestion") or "",
        "metric_value": issue.get("metric_value"),
        "line_number": issue.get("line_number") or 0,
    }


def build_project_context(scan_result: dict | None, request_context: dict | None = None) -> dict:
    if not scan_result:
        return {
            "project": {"name": "unknown", "language": "Java"},
            "summary": {"files": 0, "classes": 0, "methods": 0},
            "technical_debt": {"score": 0, "issues": 0},
            "findings": [],
            "dependencies": [],
            "graph": {},
            "selected": request_context or {},
            "evidence": [],
        }

    classes = _safe_list(scan_result.get("classes"))
    methods = []
    for cls in classes:
        for method in _safe_list(cls.get("methods")):
            methods.append({
                "class_name": cls.get("package", "") + "." + cls.get("name", ""),
                "name": method.get("name"),
                "line_count": method.get("line_count"),
                "cyclomatic_complexity": method.get("cyclomatic_complexity"),
            })

    debt_report = scan_result.get("debt_report") or {}
    issues = [_extract_root_issue(issue, index) for index, issue in enumerate(_safe_list(debt_report.get("issues")))]
    dependency_report = scan_result.get("dependency_report") or {}
    project_statistics = scan_result.get("statistics") or {}
    graph_summary = project_statistics.get("graph") or {}

    project = {
        "name": scan_result.get("project_name") or "Unknown Project",
        "language": "Java",
        "build_system": dependency_report.get("build_tool") or "unknown",
        "path": scan_result.get("project_path") or "",
    }

    summary = {
        "files": project_statistics.get("parsed_files") or 0,
        "classes": project_statistics.get("total_classes") or len(classes),
        "methods": len(methods),
        "dependencies": project_statistics.get("dependency_edges") or 0,
    }

    technical_debt = {
        "score": debt_report.get("total_score") or 0,
        "issues": len(issues),
        "severity_counts": debt_report.get("severity_counts") or {},
        "top_offenders": _safe_list(debt_report.get("top_offenders"))[:5],
    }

    evidence = []
    for issue in issues[:5]:
        if issue.get("class_name"):
            evidence.append({
                "class_name": issue.get("class_name"),
                "rule": issue.get("rule"),
                "severity": issue.get("severity"),
                "message": issue.get("message"),
                "line_number": issue.get("line_number"),
            })

    selected = request_context or {
        "file": "",
        "class": "",
        "method": "",
        "finding_id": "",
    }

    return {
        "project": project,
        "summary": summary,
        "technical_debt": technical_debt,
        "findings": issues,
        "dependencies": _safe_list(dependency_report.get("dependencies")),
        "graph": graph_summary,
        "selected": selected,
        "evidence": evidence,
        "project_file_count": summary["files"],
        "project_class_count": summary["classes"],
    }
