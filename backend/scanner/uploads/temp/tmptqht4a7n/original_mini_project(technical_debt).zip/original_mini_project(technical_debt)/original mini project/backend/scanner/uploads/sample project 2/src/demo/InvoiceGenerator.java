package demo;

import java.util.ArrayList;
import java.util.List;

public class InvoiceGenerator {
    private final List<String> invoices = new ArrayList<>();

    public String createInvoice(String customerId, double subtotal, boolean hasTax, boolean hasShipping) {
        double total = subtotal;
        if (hasTax) {
            total += subtotal * 0.15;
        }
        if (hasShipping) {
            total += 25.0;
        }
        String invoiceId = "INV-" + System.currentTimeMillis();
        invoices.add(invoiceId + ":" + customerId + ":" + total);
        return invoiceId;
    }

    public double calculateTotal(String customerId, double subtotal, boolean hasTax, boolean hasShipping) {
        double total = subtotal;
        if (hasTax) {
            total += subtotal * 0.18;
        }
        if (hasShipping) {
            total += 30.0;
        }
        return total;
    }

    public List<String> getInvoices() {
        return invoices;
    }
}
