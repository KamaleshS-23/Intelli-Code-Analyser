package demo;

import java.util.ArrayList;
import java.util.List;

public class AuditLogService {
    private final List<String> logs = new ArrayList<>();

    public void recordLogin(String userName) {
        logs.add("LOGIN:" + userName + ":" + System.currentTimeMillis());
    }

    public void recordPayment(String customerId, double amount) {
        logs.add("PAYMENT:" + customerId + ":" + amount);
    }

    public void recordInvoice(String invoiceId) {
        logs.add("INVOICE:" + invoiceId);
    }

    public List<String> getLogs() {
        return logs;
    }
}
