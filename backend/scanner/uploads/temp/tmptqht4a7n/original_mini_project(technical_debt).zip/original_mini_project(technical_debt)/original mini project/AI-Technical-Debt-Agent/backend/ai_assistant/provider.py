import json
import urllib.error
import urllib.request
from abc import ABC, abstractmethod

from .config import get_ai_settings


def _format_provider_error(provider: str, exc: Exception) -> str:
    status = getattr(exc, "code", None)
    message = str(exc)
    body_detail = ""
    if hasattr(exc, "read"):
        try:
            body = exc.read().decode("utf-8", errors="replace")
            data = json.loads(body)
            if "error" in data and isinstance(data["error"], dict) and "message" in data["error"]:
                body_detail = f": {data['error']['message']}"
            elif "error" in data and isinstance(data["error"], str):
                body_detail = f": {data['error']}"
        except Exception:
            pass

    if status == 404:
        return (
            f"{provider} returned 404 Not Found{body_detail}. Check that AI_MODEL is valid for your provider "
            "and that the API URL/key matches the account you are using."
        )
    if status == 401:
        return f"{provider} rejected the API key or token{body_detail}. Verify the key is valid and not expired."
    if status == 429:
        return f"{provider} rate limit exceeded{body_detail}. Please wait a moment before retrying."
    if status == 403:
        return f"{provider} request was forbidden (HTTP 403){body_detail}."
    if status is not None:
        return f"{provider} request failed with HTTP {status}: {message}{body_detail}"
    return f"{provider} request failed: {message}"


class AIProvider(ABC):
    @abstractmethod
    def generate(self, prompt: str, context: dict | None = None) -> str:
        raise NotImplementedError


class FallbackProvider(AIProvider):
    def __init__(self, providers: list[AIProvider] | None = None):
        self.providers = providers or []

    def generate(self, prompt: str, context: dict | None = None) -> str:
        if not self.providers:
            raise RuntimeError("No AI providers are configured.")

        errors: list[str] = []
        for provider in self.providers:
            try:
                return provider.generate(prompt, context)
            except Exception as exc:  # noqa: BLE001
                errors.append(str(exc))

        raise RuntimeError("All configured AI providers failed: " + "; ".join(errors))


class GeminiProvider(AIProvider):
    def __init__(self):
        settings = get_ai_settings()
        self.api_key = settings.gemini_api_key
        self.model = settings.model
        self.timeout = settings.timeout

    def generate(self, prompt: str, context: dict | None = None) -> str:
        if not self.api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured.")

        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1024},
        }

        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model}:generateContent?key={self.api_key}"
        )

        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                body = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise RuntimeError(_format_provider_error("Gemini", exc)) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(_format_provider_error("Gemini", exc)) from exc

        candidates = body.get("candidates") or []
        if not candidates:
            raise ValueError("Gemini returned no content.")

        parts = candidates[0].get("content", {}).get("parts", [])
        if not parts:
            raise ValueError("Gemini response did not include text parts.")

        return "".join(part.get("text", "") for part in parts if isinstance(part, dict)).strip()


class OpenAICompatibleProvider(AIProvider):
    def __init__(self):
        settings = get_ai_settings()
        self.api_key = settings.openai_api_key or settings.gemini_api_key
        self.model = settings.model
        self.base_url = settings.openai_base_url
        self.timeout = settings.timeout

    def generate(self, prompt: str, context: dict | None = None) -> str:
        if not self.api_key:
            raise RuntimeError("OpenAI API key is not configured.")

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "You are an AI technical debt assistant for a Java project analyzer. Use only the facts provided in the project context and stay grounded in actual data."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.2,
        }

        request = urllib.request.Request(
            self.base_url.rstrip("/") + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                body = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise RuntimeError(_format_provider_error("OpenAI-compatible API", exc)) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(_format_provider_error("OpenAI-compatible API", exc)) from exc

        choices = body.get("choices") or []
        if not choices:
            raise ValueError("OpenAI-compatible provider returned no content.")

        message = choices[0].get("message", {}).get("content", "")
        if isinstance(message, list):
            return "".join(part.get("text", "") for part in message if isinstance(part, dict)).strip()
        return str(message).strip()


def _build_provider_candidates() -> list[AIProvider]:
    settings = get_ai_settings()
    preferred = (settings.provider or "groq").lower()

    candidates: list[AIProvider] = []
    if preferred in {"groq", "openai", "openai_compatible", "auto"} and (settings.openai_api_key or settings.openai_base_url):
        candidates.append(OpenAICompatibleProvider())
    if preferred in {"gemini"} and settings.gemini_api_key:
        candidates.append(GeminiProvider())

    if preferred == "auto":
        if settings.gemini_api_key:
            candidates.append(GeminiProvider())
        if settings.openai_api_key or settings.openai_base_url:
            candidates.append(OpenAICompatibleProvider())

    if not candidates and settings.gemini_api_key:
        candidates.append(GeminiProvider())
    if not candidates and (settings.openai_api_key or settings.openai_base_url):
        candidates.append(OpenAICompatibleProvider())

    return candidates


def get_provider() -> AIProvider:
    candidates = _build_provider_candidates()
    if not candidates:
        return GeminiProvider()
    if len(candidates) == 1:
        return candidates[0]
    return FallbackProvider(candidates)
