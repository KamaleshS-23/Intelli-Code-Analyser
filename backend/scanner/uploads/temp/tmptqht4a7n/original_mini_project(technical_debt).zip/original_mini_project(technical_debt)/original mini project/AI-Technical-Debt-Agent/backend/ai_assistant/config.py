import os
from dataclasses import dataclass
from pathlib import Path


def _load_env_file(override: bool = False) -> None:
    candidates = [
        Path(__file__).resolve().parent.parent.parent / ".env",
        Path.cwd() / ".env",
        Path(__file__).resolve().parent.parent / ".env",
    ]
    for env_path in candidates:
        if not env_path.exists():
            continue

        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue

            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()

            if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
                value = value[1:-1]

            if override or key not in os.environ:
                os.environ[key] = value


_load_env_file(override=True)


@dataclass(frozen=True)
class AISettings:
    provider: str
    model: str
    gemini_api_key: str
    openai_api_key: str
    openai_base_url: str
    timeout: int

    @property
    def is_enabled(self) -> bool:
        provider = (self.provider or "auto").lower()
        if provider == "auto":
            return bool(self.gemini_api_key or self.openai_api_key or self.openai_base_url)
        if provider == "gemini":
            return bool(self.gemini_api_key)
        if provider in {"openai", "openai_compatible", "groq"}:
            return bool(self.openai_api_key or self.openai_base_url)
        return False


def get_ai_settings() -> AISettings:
    _load_env_file(override=True)
    provider = (os.getenv("AI_PROVIDER", "groq") or "groq").lower()
    model = os.getenv("AI_MODEL", "openai/gpt-oss-120b")
    if provider == "groq" and model == "llama-3.3-70b-versatile":
        model = "openai/gpt-oss-120b"
    return AISettings(
        provider=provider,
        model=model,
        gemini_api_key=os.getenv("GEMINI_API_KEY", ""),
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
        openai_base_url=os.getenv("OPENAI_BASE_URL", "https://api.groq.com/openai/v1"),
        timeout=int(os.getenv("AI_TIMEOUT", "30")),
    )
