package demo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReportExporter {
    private List<String> rows = new ArrayList<>();

    public void exportCsv(String fileName, String[] values) {
        try {
            File file = new File(fileName);
            FileWriter writer = new FileWriter(file);
            for (String value : values) {
                writer.write(value + ",");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addRow(String row) {
        rows.add(row);
    }

    public List<String> getRows() {
        return rows;
    }
}
